<div align="center">

![Logo][AbatabLieutenantLogo]

# DESIGN DOCUMENT

</div>

[AbatabLieutenantLogo]: ../../resources/images/logos/AbatabLieutenantLogo.png
