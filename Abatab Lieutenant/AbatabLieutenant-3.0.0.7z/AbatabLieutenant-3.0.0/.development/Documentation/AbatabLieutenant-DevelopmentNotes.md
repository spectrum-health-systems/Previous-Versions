# Development notes

## Remote functionality

Every minute, check for a request to update in the public folder.

## Flow

```mermaid
  graph TD;
      A-->B;
      A-->C;
      B-->D;
      C-->D;
```