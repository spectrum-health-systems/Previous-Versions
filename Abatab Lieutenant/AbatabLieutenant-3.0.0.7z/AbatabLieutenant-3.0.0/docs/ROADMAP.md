<div align="center">

![Logo][Logo]

# ROADMAP

</div>

# v3.0

* There is a bug that won't let AbatabLieutenant run if `C:\AbatabData\Lieutenant\Logs` does not exist.
* List custom branch in help

# v4.0

* Individual file downloads (~10MB) instead of the entire repository (~100MB).
