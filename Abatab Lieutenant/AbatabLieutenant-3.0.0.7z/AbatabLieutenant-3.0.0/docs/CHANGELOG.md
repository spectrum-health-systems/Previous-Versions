<div align="center">

![Logo][Logo]

# CHANGELOG

</div>

# Version 3.x

## v3.0.0 (February x, 2023)

# Version 2.x

## v2.0.0 (December 8, 2022)

* `INFO` Initial v2.x release
* `NEW` Settings are now stored in a local configuration file
* `NEW` Option to deploy mulitple branches
* `NEW` Help information

<br>

# Version 1.x

## v1.0.1 (October 4, 2022)

* `CHANGE` Log files now have a **.lieutenant** extension

## v1.0.0 (September 29, 2022)

* `INFO`  Initial v1.x release

[Logo]: ../resources/images/logos/AbatabLieutenantLogo.png